﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cuadrado;

namespace Proyecto1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*string miTexto = "Hola!";
            Console.Write("Acá iría mi texto: {0}", miTexto);*/

            //Ejercicio 2

            double numero=0;

            do{
                Console.Write("Ingrese un numero: ");
                double.TryParse(System.Console.ReadLine(), out numero);
                Cuadrado.Cuadrado.Potenciar(numero);

            } while(double.TryParse(System.Console.ReadLine(), out numero));
            
        



            //System.Console.ReadKey();
        }
    }
}
