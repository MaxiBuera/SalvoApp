﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cuadrado
{
    public  class Cuadrado
    {
        //private static double numeroInterno;

        public static bool validarNumero(double numero)
        {

            if(numero < 0)
            {

                return false;
            }

            else
            {
                return true;
            }
        }

        public static void Potenciar(double numero)
        {

            if(validarNumero(numero) == true)
            {

                System.Console.WriteLine(Math.Pow(numero,2));
                
            }
            else
            {
                System.Console.WriteLine("ERROR. ¡Reingresar número!");
            }
        }
    }
}
