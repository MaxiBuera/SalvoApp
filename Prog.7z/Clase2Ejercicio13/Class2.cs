﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class CalculoDeArea
    {
        public static double CalcularCuadrado(double lado)
        {
  
            double areaCuadrado = Math.Pow(lado, 2);

            return areaCuadrado;
        }

        public static double CalcularTriangulo(double b, double a)
        {

            double areaTriangulo = (b * a) / 2;

            return areaTriangulo;
        }

        public static double CalcularCirculo(double radio)
        {
           
            double areaCirculo = 3.14159265358979 * Math.Pow(radio, 2);

            return areaCirculo;
        }

    }
}
