﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Conversor
    {
        public static string DecimalBinario(int entero)
        {
            string binario;

            binario = Convert.ToString(entero, 2);

            return binario;
        }

        public static int BinarioDecimal(string binario)
        {
            char[] array = binario.ToCharArray();
            // Invertido pues los valores van incrementandose de derecha a izquierda: 16-8-4-2-1
            Array.Reverse(array);
            int entero = 0;

            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] == '1')
                {
                    // Usamos la potencia de 2, según la posición
                    entero += (int)Math.Pow(2, i);
                }
            }
            return entero;
        }

    }
}
