﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {

            /*Ejercicio 13
            System.Console.WriteLine("Convirtiendo entero '10' en Binario: ");
            System.Console.WriteLine(ConsoleApp3.Conversor.DecimalBinario(10));
            System.Console.WriteLine("Convirtiendo binario '1010' en Decimal: ");
            System.Console.WriteLine(ConsoleApp3.Conversor.BinarioDecimal("1010"));
            System.Console.ReadKey();*/

            //Ejercicio 14
            System.Console.WriteLine("Convirtiendo entero '10' en Binario: ");
        }
    }
}
