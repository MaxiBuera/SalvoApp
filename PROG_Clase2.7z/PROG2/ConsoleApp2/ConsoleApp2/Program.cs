﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            //       Condicion                       verdadero       falso
            //return int.TryParse(valor, out num1) ? num1 + numero : numero;

            /*
            String n = "jor";
            String a = "ge";
            Console.WriteLine("Empleado: {0}{1}", n, a);*/

            Empleado a = new Empleado();

            Console.ReadKey();
        }
    }
}
