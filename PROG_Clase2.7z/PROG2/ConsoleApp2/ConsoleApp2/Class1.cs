﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Empleado
    {
        private String Nombre;
        private String Apellido;
        private double SueldoBruto;
        private double SueldoNeto;
        private double Jubilacion;
        private double Ley19032;
        private double ObraSocial;
        private double Sindicato;
        private int Dni;

        public Empleado()
        {
        }

        public Empleado(String Nombre, String Apellido, double SueldoBruto, double SueldoNeto, double Jubilacion, double Ley19032, double ObraSocial) {

            this.Nombre = Nombre;
            this.Apellido = Apellido;
            this.SueldoBruto = SueldoBruto;
            this.SueldoNeto = SueldoNeto;
            this.Jubilacion = Jubilacion;
            this.Ley19032 = Ley19032;
            this.ObraSocial = ObraSocial;
        }

        public Empleado(String Nombre, String Apellido, double SueldoNeto)
        {

            this.Nombre = Nombre;
            this.Apellido = Apellido;
            this.SueldoNeto = SueldoNeto;
        }

        public void CalcularNeto(double SueldoBruto)
        {

            Jubilacion = (SueldoBruto * 11) / 100;
            ObraSocial = (SueldoBruto * 3) / 100;
            Ley19032 = (SueldoBruto * 3) / 100;
            //SueldoNeto = (SueldoBruto * 83) / 100;
        }

        public void CalcularNeto(double SueldoBruto, bool sindicato)
        {
            this.CalcularNeto(SueldoBruto);

            if (sindicato)
            {
                Sindicato = (SueldoBruto * 2) / 100;
                SueldoNeto = (SueldoBruto * 81) / 100;
            }
            else
            {
                SueldoNeto = (SueldoBruto * 83) / 100;
            }
          
        }

        public void Aumento(float aumento)
        {
            
            SueldoBruto = SueldoBruto + aumento;
            this.CalcularNeto(SueldoBruto);
        }

        public void Aumento(int aumento)
        {
            SueldoBruto = SueldoBruto + ((SueldoBruto * aumento) / 100);
            this.CalcularNeto(SueldoBruto);
        }

        /*public static void operator +(){
            
        }*/

        public static int operator ==()
        {

        }
    } 
}
